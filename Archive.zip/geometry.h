#ifndef __GEOMETRY_H_
#define __GEOMETRY_H_

#include <vector>

using std::vector;

static inline vector<double> linspan(double a, double b, int n) {
  vector<double> result;
  if (n <= 0) {
    return result;
  }
  
  if (n == 1) {
    result.push_back((a+b)/2.0);
    return result;
  }
  
  if (n == 2) {
    result.push_back(a);
    result.push_back(b);
    return result;
  }
  
  for (int i = 0; i < n; i++) {
    result.push_back(a + (b - a) * i/(n-1));
  }
  
  return result;
}

#endif
