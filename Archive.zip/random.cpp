#include "random.h"

mt19937 rng;
