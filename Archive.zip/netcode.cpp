#include <cstring>
#include <cstdio>
#include <cstdlib>
#include <unistd.h>
#include <netdb.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include "netcode.h"

const size_t BUFSIZE = 1024;

static void error(char *s) {
  printf("%s\n", s);
}

typedef struct {
  int fr;
  char *data;
  int len;
} t_packet;

void init_server() {
  pthread_t thread1;
  const char *message1 = "Thread 1";
  int  iret1;
  iret1 = pthread_create(&thread1, NULL, sthread, (void*) message1);
}

void *sthread( void *ptr ) {
  int sockfd;    /* socket */
  int portno;    /* port to listen on */
  socklen_t clientlen;    /* byte size of client's address */
  struct sockaddr_in serveraddr;  /* server's addr */
  struct sockaddr_in clientaddr;  /* client addr */
  struct hostent *hostp;  /* client host info */
  char *buf;    /* message buf */
  char *hostaddrp;  /* dotted decimal host addr string */
  int optval;    /* flag value for setsockopt */
  ssize_t n;      /* message byte size */
  
  portno = 2666;
  sockfd = socket(AF_INET, SOCK_DGRAM, 0);
  if (sockfd < 0)
    error("ERROR opening socket");
  
  /* setsockopt: Handy debugging trick that lets
   * us rerun the server immediately after we kill it;
   * otherwise we have to wait about 20 secs.
   * Eliminates "ERROR on binding: Address already in use" error.
   */
  optval = 1;
  setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR,
             (const void *)&optval, sizeof(int));
  
  /*
   * build the server's Internet address
   */
  bzero((char *)&serveraddr, sizeof(serveraddr));
  serveraddr.sin_family = AF_INET;
  serveraddr.sin_addr.s_addr = htonl(INADDR_ANY);
  serveraddr.sin_port = htons((unsigned short)portno);
  
  /*
   * bind: associate the parent socket with a port
   */
  if (bind(sockfd, (struct sockaddr *)&serveraddr,
           sizeof(serveraddr)) < 0)
    error("ERROR on binding");
  
  /*
   * main loop: wait for a datagram, then echo it
   */
  clientlen = sizeof(clientaddr);
  while (1) {
    
    /*
     * recvfrom: receive a UDP datagram from a client
     */
    buf = (char *)malloc(BUFSIZE);
    //recvfrom(int, void *, size_t, int, struct sockaddr * __restrict,
//    socklen_t * __restrict) __DARWIN_ALIAS_C(recvfrom);
    n = recvfrom(sockfd, (void *)buf, (size_t)BUFSIZE, 0,
                 (struct sockaddr *)&clientaddr, &clientlen);
    if (n < 0)
      error("ERROR in recvfrom");
    
    /*
     * gethostbyaddr: determine who sent the datagram
     */
    hostp = gethostbyaddr((const char *)&clientaddr.sin_addr.s_addr,
                          sizeof(clientaddr.sin_addr.s_addr),
                          AF_INET);
    if (hostp == NULL)
      error("ERROR on gethostbyaddr");
    hostaddrp = inet_ntoa(clientaddr.sin_addr);
    if (hostaddrp == NULL)
      error("ERROR on inet_ntoa\n");
    /*printf("server received %d bytes\n", n); */
    
    /*
     * sendto: echo the input back to the client
     */
    n = sendto(sockfd, buf, n, 0,
               (struct sockaddr *)&clientaddr, clientlen);
    buf[clientlen] = '\0';
    printf("%s]\n", buf);
    if (n < 0)
      error("ERROR in sendto");
  }
}
