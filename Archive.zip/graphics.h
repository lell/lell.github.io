#ifndef __GRAPHICS_H_
#define __GRAPHICS_H_

#include <cstdlib>
#include <cstdio>
#include <cmath>

#include <vector>
#include <string>
#include <map>

#include <SDL3/SDL.h>
#include <SDL3/SDL_render.h>
#include "SDL_image.h"
#include "SDL3_gfx/SDL3_gfxPrimitives.h"
#include <boost/format.hpp>

#include <armadillo>

using arma::mat;

using std::vector;
using std::string;
using std::map;

using boost::format;

class Matrix {
public:
  Matrix();
  Matrix(SDL_Surface *surface);
  Matrix(SDL_Texture *texture1);
  Matrix blur(int k, double alpha);
  void dump(SDL_Surface *surface);
  SDL_Surface *dump(SDL_PixelFormat format);
  SDL_Surface *dump();
  SDL_Texture *dump2();
  ~Matrix();
  
private:
  void process(SDL_Surface *surface);
  double *rs;
  double *gs;
  double *bs;
  double *as;
  mat *Rs;
  mat *Gs;
  mat *Bs;
  mat *As;
  
};

static inline SDL_Color tc(Uint8 r, Uint8 g, Uint8 b, Uint8 a) {
  SDL_Color value = {r, g, b, a};
  return value;
}

static inline SDL_FRect fr(int x, int y, int w, int h) {
  SDL_FRect result;
  result.x = x;
  result.y = y;
  result.w = w;
  result.h = h;
  return result;
}

typedef struct {
  double x;
  double y;
} Point;

class Element {
public:
  static Element *get(string name);
  static Element *create(SDL_Surface *surface, string name, int blur, int TH);
  static Element *create(SDL_Texture *texture1, SDL_Texture *texture2, string name, int blur, int TH);
  string name;
  static void draw(string name, int x, int y);
  int width;
  
private:
  static map<string, Element *> s;
  double last_used;
  int TH;
  vector<double> times;
  vector<SDL_Texture *> frames;
  vector<SDL_Texture *> rs;
  vector<SDL_Texture *> gs;
  vector<SDL_Texture *> bs;
  vector<Point> ors;
  vector<Point> ogs;
  vector<Point> obs;
  void process(SDL_Surface *surface, SDL_Texture *texture1, SDL_Texture *texture2, string name, int blur);
  Element(SDL_Surface *surface, SDL_Texture *texture1, SDL_Texture *texture2, string name, int blur);

};

extern SDL_Window *window;
extern SDL_Surface *canvas;
extern SDL_Renderer *renderer;
extern SDL_Surface *screen;
extern SDL_Renderer *software;
extern SDL_PixelFormat PF;
extern SDL_Texture *interlace;
extern SDL_Texture *display;
extern SDL_Texture *temp;

extern SDL_Texture *DR;
extern SDL_Texture *DG;
extern SDL_Texture *DB;

extern SDL_Texture *dR;
extern SDL_Texture *dG;
extern SDL_Texture *dB;
extern int SW;
extern int SH;
extern SDL_BlendMode bm;

void init_graphics();
void refresh();
void draw_line(int x1, int y1, int x2, int y2, int r, int g, int b, int a);
void draw_line2(double x1, double y1, double x2, double y2, int r, int g, int b, int a);


class Draw {
public:
  string id;
  Element *element = NULL;
  double x, y;
  int w, h;
  Draw() { }
  virtual ~Draw() = default;
  virtual void execute(SDL_Texture *texture) = 0;
  void draw() {
    if (element == NULL) {
      printf("draw wh: %d %d\n", w, h);
      printf("Drawing: %s\n", id.c_str());
      element = Element::get(id);
      if (element == NULL) {
        if (w <= 0) {
          printf("Error: Element with 0 width.\n");
          exit(-1);
        }
        if (h <= 0) {
          printf("Error: Element with 0 height.\n");
          exit(-1);
        }
        SDL_Texture *texture1 = SDL_CreateTexture(renderer, PF, SDL_TEXTUREACCESS_TARGET, w, h);
        SDL_SetTextureBlendMode(texture1, SDL_BLENDMODE_BLEND);
        SDL_SetRenderTarget(renderer, texture1);
        execute(texture1);
        SDL_SetRenderDrawColor(renderer, 0, 0, 0, 0);
        SDL_SetRenderTarget(renderer, NULL);
        
        SDL_Texture *texture2 = SDL_CreateTexture(renderer, PF, SDL_TEXTUREACCESS_STREAMING, w, h);
        SDL_SetTextureBlendMode(texture2, SDL_BLENDMODE_BLEND);
        SDL_SetRenderTarget(renderer, texture2);
        execute(texture2);
        SDL_SetRenderDrawColor(renderer, 0, 0, 0, 0);
        SDL_SetRenderTarget(renderer, NULL);
        element = Element::create(texture1, texture2, id, 27, 0);
        SDL_DestroyTexture(texture2);
        
        
      }
    }
    
    Element::draw(id, x + w/2.0, y + h/2.0);
  }
private:
};

class Line: public Draw {
  double u, v;
  int r, g, b, a;
public:
  Line(double x1, double y1, double x2, double y2, int r, int g, int b, int a) :
  r(r), g(g), b(b), a(a) {
    if (x1 > x2) {
      double temp;
      
      temp = x2;
      x2 = x1;
      x1 = temp;
      
      temp = y2;
      y2 = y1;
      y1 = temp;
    }
    
    u = x2 - x1;
    v = y2 - y1;
    
    int ui = u;
    int vi = v;
    id = (format("line[%d,%d,%d,%d,%d,%d]") % ui % vi % r % g % b % a).str();
    printf("Creating: %s\n", id.c_str());
    
    w = u + 5;
    h = fabs(v) + 5;
    x = x1 + w/2;
    y = y1 + v/2;
    printf("Line wh: %d %d\n", w, h);
  }
  
  void execute(SDL_Texture *texture) {
    printf("execute wh: %d %d\n", w, h);
    printf("Executing: %s\n", id.c_str());
    if (v > 0) {
      thickLineRGBA(renderer, 2.5, 2.5, u + 2.5, v + 2.5, 5, r, g, b, a);
    } else {
      int v2 = -v + 2.5;
      v2 = fabs(v2);
      printf("v v2 %f %d\n", v, v2);
      thickLineRGBA(renderer, 2.5, v2, u + 2.5, 2.5, 5, r, g, b, a);
    }
  }
};

#endif
