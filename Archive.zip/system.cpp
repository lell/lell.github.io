#include "system.h"

#include <cmath>
#include <chrono>
#include <boost/dll.hpp>
#include <boost/filesystem.hpp>
#include "nadeau.h"
#include "random.h"


using namespace boost::filesystem;
using boost::dll::program_location;

double now = -INFINITY;
double start = -INFINITY;

double current() {
  double result = (std::chrono::duration_cast
                   <std::chrono::milliseconds>
                   (std::chrono::system_clock::now().time_since_epoch())).count();
  result = result / 1000.0f;
  
  return result;
}

double upnow() {
  if (start < 0) {
    start = current();
  }
  double result = current();
  now = result - start;
  return now;
}

double usage() {
  static size_t pagesize = sysconf(_SC_PAGESIZE);
  int64_t bytes = getCurrentRSS();
  
  return bytes / 1024.0f / 1024.0f; // in KB
}
void init_system() {
  start = current();
  path arg0 = program_location();
  path wd = arg0.parent_path();
  std::cout << wd.string() << std::endl;
  if(is_directory(wd)) {
    std::cout << wd << " is a directory containing:\n";
    
    for(auto& entry : boost::make_iterator_range(directory_iterator(wd), {}))
      std::cout << entry << "\n";
  }
  current_path(wd);
  for(int i = 0; i < 100; i++)
    std::cout << uniform(0, 3) << '\n';
}
