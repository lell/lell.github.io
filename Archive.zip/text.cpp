#include <boost/format.hpp>
#include "text.h"
#include "graphics.h"

using boost::format;

Font::Font(string name, int size, int blur) : name(name), blur(blur) {
  TH = size;
  font = TTF_OpenFont(name.c_str(), TH);
  if (font == NULL) {
    printf("SDL could not open font! SDL_Error: %s\n", SDL_GetError());
    exit(-1);
  }
  printf("Created font\n");
}

void Font::draw_text(string text, int x, int y, int r, int g, int b, int a) {
  string id = (format("[%s,%d,%d,%d,%d]%s") % name % r % g % b % a % text).str();
  Element *element = Element::get(id);
  if (element == NULL) {
    SDL_Surface *surface = TTF_RenderText_Blended(font, text.c_str(), 0, tc(r,g,b,a));
    element = Element::create(surface, id, blur, TH);
    SDL_DestroySurface(surface);
  }
  
  Element::draw(id, x, y);
}

void Font::draw_textl(string text, int x, int y, int r, int g, int b, int a) {
  string id = (format("[%s,%d,%d,%d,%d]%s") % name % r % g % b % a % text).str();
  Element *element = Element::get(id);
  if (element == NULL) {
    SDL_Surface *surface = TTF_RenderText_Blended(font, text.c_str(), 0, tc(r,g,b,a));
    element = Element::create(surface, id, blur, TH);
    SDL_DestroySurface(surface);
  }
  int w = element->width;
  Element::draw(id, x + w/2, y);
}
