#ifndef __MACHINE_H_
#define __MACHINE_H_

#include <set>
#include "cereal/cereal.hpp"
#include "cereal/types/concepts/pair_associative_container.hpp"
#include "cereal/types/unordered_map.hpp"
#include "cereal/types/memory.hpp"
#include "cereal/archives/binary.hpp"

using std::set;

enum MACHINE {
  NIGHTSTALKER,
  BEHEMOTH,
  SWITCHBLADE,
  TREBUCHET
};

class Game;

class Aspect {
public:
  Game *game;
  Aspect(Game *game) : game(game) {}
  virtual void advance(Game *next) = 0;
  template<class Archive>
  void serialize(Archive &archive) {
    archive();
  }
};

class Game {
public:
  Uint64 tick;
  vector<Aspect *> aspects;
  
  Game(Uint64 tick) : tick(tick) { }
  void add(Aspect *aspect) {
    aspect->game = this;
    aspects.push_back(aspect);
  }
  
  Game *advance() {
    Game *next = new Game(tick + 1);
    for (Aspect *aspect : aspects) {
      aspect->advance(next);
    }
    return next;
  }
  
  template<class Archive>
  void serialize(Archive &archive) {
    archive(tick, aspects);
  }
};

class Machine : public Aspect {
public:
  Sint64 x,y;
  Sint64 dx, dy;
  Sint16 theta;
  template<class Archive>
  void serialize(Archive &archive) {
    archive(x, y, dx, dy, theta);
  }
  
  Machine() : Aspect(NULL),
  x(0),
  y(0),
  dx(0),
  dy(0),
  theta(0)
  { }
  
  Machine(Machine *other) : Aspect(other->game),
  x(other->x),
  y(other->y),
  dx(other->dx),
  dy(other->dy),
  theta(other->theta)
  { }
  
  void advance(Game *next) {
    Machine *aspect = new Machine(this);
    aspect->x += dx;
    aspect->y += dy;
    next->add(aspect);
  }
};


#endif
