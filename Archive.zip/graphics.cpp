#include <cassert>
#include <cmath>
#include <boost/format.hpp>
#include <SDL3/SDL.h>
#include <SDL3/SDL_render.h>
#include <armadillo>

#include "SDL3_gfx/SDL3_gfxPrimitives.h"

#include "graphics.h"
#include "system.h"
#include "random.h"
#include "text.h"

using namespace arma;
using boost::format;

SDL_Window *window;
SDL_Surface *canvas;
SDL_Renderer *renderer;
SDL_PixelFormat PF;
SDL_Texture *interlace;
SDL_Texture *display;
SDL_Texture *temp;
SDL_Texture *DR;
SDL_Texture *DG;
SDL_Texture *DB;
SDL_Texture *dR;
SDL_Texture *dG;
SDL_Texture *dB;
int SW;
int SH;
SDL_BlendMode bm;

Font *fsystem;
Font *fmenu;
Font *flogo;

double reset = -INFINITY;
unsigned long frame = 0;
string fps = "NaN";


void refresh() {
  upnow();
  frame++;
  if (now - reset > 1) {
    fps = (format("%0.1ffps %0.1fMB") % (frame/(now - reset)) % usage()).str();
    frame = 0;
    reset = now;
  }
    
  SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
  SDL_RenderClear(renderer);
  
  SDL_SetRenderTarget(renderer, DR);
  SDL_SetRenderDrawColor(renderer, 0, 0, 0, 0);
  SDL_RenderClear(renderer);
  SDL_SetRenderTarget(renderer, NULL);
  
  SDL_SetRenderTarget(renderer, DG);
  SDL_SetRenderDrawColor(renderer, 0, 0, 0, 0);
  SDL_RenderClear(renderer);
  SDL_SetRenderTarget(renderer, NULL);
  
  SDL_SetRenderTarget(renderer, DB);
  SDL_SetRenderDrawColor(renderer, 0, 0, 0, 0);
  SDL_RenderClear(renderer);
  SDL_SetRenderTarget(renderer, NULL);
  
  SDL_SetRenderTarget(renderer, display);
  SDL_SetRenderDrawColor(renderer, 0, 0, 0, 0);
  SDL_RenderClear(renderer);
  SDL_SetRenderTarget(renderer, NULL);
  
  
  SDL_SetRenderTarget(renderer, display);
  
  fmenu->draw_text("Play Online", SW/2, SH/2 - 62, 0xea, 0xea, 0xea, 0xea);
  fmenu->draw_text("Settings", SW/2, SH/2, 0xaF, 0xaF, 0xaF, 0xaF);
  fmenu->draw_text("Credits", SW/2, SH/2 + 62, 0xaF, 0xaF, 0xaF, 0xaF);
  fmenu->draw_text("Quit", SW/2, SH/2 + 2 * 62, 0xaF, 0xaF, 0xaF, 0xaF);
  
  flogo->draw_text("Baseduel", SW/2, 2*62, 0xaF, 0xaF, 0xaF, 0xaF);
  
  fsystem->draw_textl(fps, 0, 6, 0xFF, 0xFF, 0xFF, 0xFF);
  
  double ff = 2.5;
  draw_line2(SW/2 - 300,
             SH/2 - 2*62 - 2*ff,
             SW/2 - 300,
             SH/2 + 4*62 + 1.5*ff,
             
             0xaF, 0xaF, 0xaF, 0xaF);
  
  draw_line2(SW/2 - 300 + 1.5*ff,
             SH/2 - 2*62 - ff,
             SW/2 + 300 - ff,
             SH/2 - 2*62 - ff,
             
             0xaF, 0xaF, 0xaF, 0xaF);
  
  draw_line2(SW/2 + 300,
             SH/2 - 2*62 - 2*ff,
             SW/2 + 300,
             SH/2 + 4*62 + 1.5*ff,
             
             0xaF, 0xaF, 0xaF, 0xaF);
  
  draw_line2(SW/2 - 300 + 1.5*ff,
             SH/2 + 4*62 + ff,
             SW/2 + 300 - ff,
             SH/2 + 4*62 + ff,
             
             0xaF, 0xaF, 0xaF, 0xaF);
  
  /*static Line line1(SW/2-400, SH/2, SW/2-20-400, SH/2-20, 0xFF, 0xFF, 0xFF, 0xFF);
  line1.draw();
  
  
  static Line line2(SW/2-400, SH/2, SW/2-20-400, SH/2+20, 0xFF, 0xFF, 0xFF, 0xFF);
  line2.draw();
  
  
  static Line line3(SW/2-400, SH/2, SW/2+20-400, SH/2+20, 0xFF, 0xFF, 0xFF, 0xFF);
  line3.draw();
  
  static Line line4(SW/2-400, SH/2, SW/2+20-400, SH/2-20, 0xFF, 0xFF, 0xFF, 0xFF);
  line4.draw();*/
  
  //draw_line2(SW/2-400, SH/2, SW/2-20-400, SH/2-20, 0xFF, 0x20, 0x20, 0xFF);

  //draw_line2(SW/2-400, SH/2, SW/2-20-400, SH/2+20, 0x20, 0xFF, 0x20, 0xFF);

   
  //draw_line2(SW/2-400, SH/2, SW/2+20-400, SH/2+20, 0x20, 0x20, 0xFF, 0xFF);

  //draw_line2(SW/2-400, SH/2, SW/2+20-400, SH/2-20, 0xFF, 0x20, 0xFF, 0xFF);
  
  double which = now/2 * 2 * M_PI;
  double x = sin(which);
  double y = cos(which);
  draw_line2(SW/2-400, SH/2, SW/2-200*x-400, SH/2-200*y, 0xaf, 0xaf, 0xaf, 0xaf);

  SDL_SetRenderTarget(renderer, NULL);
  SDL_FRect loc = fr(0, 0, SW, SH);
  SDL_SetRenderTarget(renderer, display);
  SDL_SetTextureBlendMode(interlace, SDL_BLENDMODE_MOD);
  SDL_RenderTexture(renderer, interlace, NULL, &loc);
  SDL_SetRenderTarget(renderer, NULL);
  thickLineRGBA(renderer, 0, SH, SW, 0, 5, 0xFF, 0xFF, 0xFF, 0xFF); // ***
  
  SDL_SetTextureBlendMode(display, SDL_BLENDMODE_BLEND);
  SDL_RenderTexture(renderer, display, NULL, &loc);
  
  SDL_SetRenderTarget(renderer, temp);
  SDL_SetRenderDrawColor(renderer, 0, 0, 0, 0);
  SDL_RenderClear(renderer);
  SDL_SetTextureBlendMode(DR, SDL_BLENDMODE_NONE);
  
  SDL_RenderTexture(renderer, DR, NULL, &loc);
  SDL_SetTextureBlendMode(dR, SDL_BLENDMODE_MOD);
  SDL_RenderTexture(renderer, dR, NULL, &loc);
  SDL_SetRenderTarget(renderer, NULL);
  SDL_SetTextureBlendMode(temp, bm);
  SDL_RenderTexture(renderer, temp, NULL, &loc);
  
  SDL_SetRenderTarget(renderer, temp);
  SDL_SetRenderDrawColor(renderer, 0, 0, 0, 0);
  SDL_RenderClear(renderer);
  SDL_SetTextureBlendMode(DG, SDL_BLENDMODE_NONE);
  SDL_RenderTexture(renderer, DG, NULL, &loc);
  SDL_SetTextureBlendMode(dG, SDL_BLENDMODE_MOD);
  SDL_RenderTexture(renderer, dG, NULL, &loc);
  SDL_SetRenderTarget(renderer, NULL);
  SDL_SetTextureBlendMode(temp, bm);
  SDL_RenderTexture(renderer, temp, NULL, &loc);
  
  SDL_SetRenderTarget(renderer, temp);
  SDL_SetRenderDrawColor(renderer, 0, 0, 0, 0);
  SDL_RenderClear(renderer);
  SDL_SetTextureBlendMode(DB, SDL_BLENDMODE_NONE);
  SDL_RenderTexture(renderer, DB, NULL, &loc);
  SDL_SetTextureBlendMode(dB, SDL_BLENDMODE_MOD);
  SDL_RenderTexture(renderer, dB, NULL, &loc);
  SDL_SetRenderTarget(renderer, NULL);
  SDL_SetTextureBlendMode(temp, bm);
  SDL_RenderTexture(renderer, temp, NULL, &loc);
  
  SDL_SetRenderTarget(renderer, NULL);
  SDL_RenderPresent(renderer);
}

SDL_Renderer *software = NULL;
SDL_Surface *screen = NULL;

void init_graphics() {
  window = NULL;
  canvas = NULL;
  renderer = NULL;
  SW = 1280;
  SH = 800;
  
  // https://hardwaretester.com/gamepad
  if (!SDL_Init(SDL_INIT_VIDEO | SDL_INIT_GAMEPAD)) {
    printf( "SDL could not initialize. SDL error: %s\n", SDL_GetError());
    exit(-1);
  }
  
  if (!TTF_Init()) {
    printf("SDL could not initialize fonts. SDL error: %s\n", SDL_GetError());
    exit(-1);
  }
  
  fsystem = new Font("SQR721BE.TTF", 18, 27);
  fmenu = new Font("SQR721B.TTF", 62, 27);
  flogo = new Font("SQR721I.TTF", 128, 27);
  
  bm = SDL_ComposeCustomBlendMode(SDL_BLENDFACTOR_ONE, SDL_BLENDFACTOR_ONE, SDL_BLENDOPERATION_MAXIMUM, SDL_BLENDFACTOR_ONE, SDL_BLENDFACTOR_ONE, SDL_BLENDOPERATION_ADD);
  
  SDL_Window *window = SDL_CreateWindow("SDL3 Tutorial: Hello SDL3", SW, SH, 0);
  if (window == NULL) {
    printf("Window could not be created. SDL error: %s\n", SDL_GetError() );
  }
  
  PF = SDL_GetWindowPixelFormat(window);
  renderer = SDL_CreateRenderer(window, NULL);
  
  screen = SDL_CreateSurface(SW, SH, PF);
  software = SDL_CreateSoftwareRenderer(screen);
  
  
  if (renderer == NULL) {
    printf("SDL_CreateRenderer() error: %s\n", SDL_GetError());
    exit(-1);
  }
  
  interlace = SDL_CreateTexture(renderer, PF, SDL_TEXTUREACCESS_TARGET, SW, SH);
  display = SDL_CreateTexture(renderer, PF, SDL_TEXTUREACCESS_TARGET, SW, SH);
  
  //temp = SDL_CreateTexture(renderer, PF, SDL_TEXTUREACCESS_TARGET, SW, SH);
  
  DR = SDL_CreateTexture(renderer, PF, SDL_TEXTUREACCESS_TARGET, SW, SH);
  DG = SDL_CreateTexture(renderer, PF, SDL_TEXTUREACCESS_TARGET, SW, SH);
  DB = SDL_CreateTexture(renderer, PF, SDL_TEXTUREACCESS_TARGET, SW, SH);
  
  dR = SDL_CreateTexture(renderer, PF, SDL_TEXTUREACCESS_TARGET, SW, SH);
  dG = SDL_CreateTexture(renderer, PF, SDL_TEXTUREACCESS_TARGET, SW, SH);
  dB = SDL_CreateTexture(renderer, PF, SDL_TEXTUREACCESS_TARGET, SW, SH);
  
  temp = SDL_CreateTexture(renderer, PF, SDL_TEXTUREACCESS_TARGET, SW, SH);
  canvas = SDL_GetWindowSurface(window);
  
  SDL_SetRenderTarget(renderer, dR);
  SDL_SetRenderDrawColor(renderer, 0xFF, 0x00, 0x00, 0xFF);
  SDL_RenderClear(renderer);
  SDL_SetRenderTarget(renderer, NULL);
  
  SDL_SetRenderTarget(renderer, dG);
  SDL_SetRenderDrawColor(renderer, 0x00, 0xFF, 0x00, 0xFF);
  SDL_RenderClear(renderer);
  SDL_SetRenderTarget(renderer, NULL);
  
  SDL_SetRenderTarget(renderer, dB);
  SDL_SetRenderDrawColor(renderer, 0x00, 0x00, 0xFF, 0xFF);
  SDL_RenderClear(renderer);
  SDL_SetRenderTarget(renderer, NULL);
  
  SDL_SetRenderTarget(renderer, interlace);
  SDL_SetRenderDrawBlendMode(renderer, SDL_BLENDMODE_NONE);
  
  SDL_Surface *surface = IMG_Load("interlace.png");
  SDL_Texture *image = SDL_CreateTextureFromSurface(renderer, surface);
  SDL_DestroySurface(surface);
  
  for (int i = 0; i < SH; i++) {
    for (int j = 0; j < SW; j++) {
      SDL_FRect loc3 = { i * 6.0f, j * 4.0f, 6.0f, 4.f };
      SDL_RenderTexture(renderer, image, NULL, &loc3);
    }
  }
  
  SDL_SetRenderTarget(renderer, NULL);
  reset = upnow();
  printf("start: %f\n", start);
}

Matrix::Matrix() {
  this->rs = NULL;
  this->gs = NULL;
  this->bs = NULL;
  this->as = NULL;
}

void Matrix::process(SDL_Surface *surface) {
  if (surface == NULL) {
    printf("Error: Matrix called on null surface.\n");
    exit(-1);
  }
  
  if (SDL_MUSTLOCK(surface) != 0) {
    SDL_LockSurface(surface);
  }
  
  const SDL_PixelFormatDetails *details = SDL_GetPixelFormatDetails(surface->format);
  Uint8 bpp = details->bits_per_pixel;
  if (bpp != 32) {
    printf("Error: Found pixels with size %d bits.\n", bpp);
    exit(-1);
  }
  int w = surface->w;
  int h = surface->h;
  rs = (double *)malloc(sizeof(double) * w * h);
  gs = (double *)malloc(sizeof(double) * w * h);
  bs = (double *)malloc(sizeof(double) * w * h);
  as = (double *)malloc(sizeof(double) * w * h);
  
  for (int i = 0; i < w; i++) {
    for (int j = 0; j < h; j++) {
      Uint8 r;
      Uint8 g;
      Uint8 b;
      Uint8 a;
      Uint32 pixel = ((Uint32 *)(surface->pixels))[i + surface->pitch/4 * j];
      SDL_GetRGBA(pixel, details, NULL, &r, &g, &b, &a);
      rs[i + w*j] = r;
      gs[i + w*j] = g;
      bs[i + w*j] = b;
      as[i + w*j] = a;
    }
  }
  
  //mat(ptr_aux_mem, n_rows, n_cols, copy_aux_mem = true, strict = false)
  Rs = new mat(rs, w, h, false, true);
  Gs = new mat(gs, w, h, false, true);
  Bs = new mat(bs, w, h, false, true);
  As = new mat(as, w, h, false, true);
  
  
  if (SDL_MUSTLOCK(surface) != 0) {
    SDL_UnlockSurface(surface);
  }
}

Matrix::Matrix(SDL_Surface *surface) {
  process(surface);
}


Matrix::Matrix(SDL_Texture *texture) {
  int w = texture->w;
  int h = texture->h;
  SDL_SetRenderTarget(software, texture);
  SDL_SetTextureBlendMode(texture, SDL_BLENDMODE_BLEND);
  SDL_Rect loc = { 0, 0, w, h };
  //printf("Matrix wh: %d %d\n", w, h);
  SDL_Surface *surface = SDL_RenderReadPixels(software, &loc);
  SDL_SetRenderTarget(software, NULL);
  //printf("zz\n");
  process(surface);
  SDL_DestroySurface(surface);
}

void Matrix::dump(SDL_Surface *surface) {
  if (surface == NULL) {
    printf("Error: Cannot dump to an empty surface.\n");
    exit(-1);
  }
  
  if (SDL_MUSTLOCK(surface) != 0) {
    SDL_LockSurface(surface);
  }
  const SDL_PixelFormatDetails *details = SDL_GetPixelFormatDetails(surface->format);
  Uint8 bpp = details->bits_per_pixel;
  if (bpp != 32) {
    printf("Error: Found pixels with size %d bits.\n", bpp);
    exit(-1);
  }
  int w = surface->w;
  int h = surface->h;
  
  for (int i = 0; i < w; i++) {
    for (int j = 0; j < h; j++) {
      Uint8 r = (*Rs)(i, j);
      if (r < 100) {
        r = 200;
      }
      Uint8 g = (*Gs)(i, j);
      Uint8 b = (*Bs)(i, j);
      Uint8 a = (*As)(i, j);
      
      Uint32 pixel = SDL_MapSurfaceRGBA(surface, r, g, b, a);
      ((Uint32 *)(surface->pixels))[i + surface->pitch/4 * j] = pixel;
    }
  }
  if (SDL_MUSTLOCK(surface) != 0) {
    SDL_UnlockSurface(surface);
  }
}


SDL_Surface *Matrix::dump(SDL_PixelFormat format) {
  int w = (int)(Rs->n_rows);
  int h = (int)(Rs->n_cols);
  SDL_Surface *surface = SDL_CreateSurface(w, h, format);
  
  
  for (int i = 0; i < w; i++) {
    for (int j = 0; j < h; j++) {
      Uint8 r = (*Rs)(i, j);
      Uint8 g = (*Gs)(i, j);
      Uint8 b = (*Bs)(i, j);
      Uint8 a = (*As)(i, j);
      
      Uint32 pixel = SDL_MapSurfaceRGBA(surface, r, g, b, a);
      ((Uint32 *)(surface->pixels))[i + surface->pitch/4 * j] = pixel;
    }
  }
  
  return surface;
}

SDL_Surface *Matrix::dump() {
  SDL_PixelFormat format = display->format;
  return dump(format);
}

SDL_Texture *Matrix::dump2() {
  SDL_Surface *surface = this->dump();
  SDL_Texture *texture = SDL_CreateTextureFromSurface(renderer, surface);
  SDL_DestroySurface(surface);
  return texture;
}

//0 0 0
//0 0 0
//0 0 0

//0 0
//0 0

// nb - 1 + mb - 1 = nb  + mb - 2

mat myconv2(mat &a, mat &b) {
  int na = (int)a.n_rows;
  int ma = (int)a.n_cols;
  int nb = (int)b.n_rows;
  int mb = (int)b.n_cols;
  mat result(na + nb - 1, ma + mb - 1);
  result.zeros();
  for (int ia = 0; ia < na; ia++) {
    for (int ja = 0; ja < ma; ja++) {
      for (int ib = 0; ib < nb; ib++) {
        for (int jb = 0; jb < mb; jb++) {
          int i = ia + ib;
          int j = ja + jb;
          result(i, j) += a(ia, ja) * b(ib, jb);
        }
      }
    }
  }
  return result;
}

Matrix Matrix::blur(int k, double alpha) {
  Matrix result;
  result.Rs = new mat();
  result.Gs = new mat();
  result.Bs = new mat();
  result.As = new mat();
  
  mat kernel;
  switch(k) {
    /*case 1:
      kernel = { { 1.0f } };
      break;
      
    case 3:
      kernel = {
        { 1.0/16.0, 2.0/16.0, 1.0/16.0 },
        { 2.0/16.0, 4.0/16.0, 2.0/16.0 },
        { 1.0/16.0, 2.0/16.0, 1.0/16.0 }
      };
      break;
      
    case 7:
      kernel = {
        { 0.0/1003.0,  0.0/1003.0,  1.0/1003.0,   2.0/1003.0,  1.0/1003.0,  0.0/1003.0, 0.0/1003.0 },
        { 0.0/1003.0,  3.0/1003.0, 13.0/1003.0,  22.0/1003.0, 13.0/1003.0,  3.0/1003.0, 0.0/1003.0 },
        { 1.0/1003.0, 13.0/1003.0, 59.0/1003.0,  97.0/1003.0, 59.0/1003.0, 13.0/1003.0, 1.0/1003.0 },
        { 2.0/1003.0, 22.0/1003.0, 97.0/1003.0, 159.0/1003.0, 97.0/1003.0, 22.0/1003.0, 2.0/1003.0 },
        { 1.0/1003.0, 13.0/1003.0, 59.0/1003.0,  97.0/1003.0, 59.0/1003.0, 13.0/1003.0, 1.0/1003.0 },
        { 0.0/1003.0,  3.0/1003.0, 13.0/1003.0,  22.0/1003.0, 13.0/1003.0,  3.0/1003.0, 0.0/1003.0 },
        { 0.0/1003.0,  0.0/1003.0,  1.0/1003.0,   2.0/1003.0,  1.0/1003.0,  0.0/1003.0, 0.0/1003.0 }
      };
      break;*/
      
    default:
      k = 5;
      kernel.set_size(k, k);
      double norm = 0.0;
      double sigma2 = (5+1)/2;
      double sigma = sqrt(sigma2);
      for (int i = 0; i < k; i++) {
        for (int j = 0; j < k; j++) {
          double x = i + 0.5 - k/2.0;
          double y = j + 0.5 - k/2.0;
          double value = 0.055 * exp(-(x*x + y*y)/(2.0 * sigma2));
          kernel(i, j) = value;
          norm = norm + value;
        }
      }
      
      for (int i = 0; i < k; i++) {
        for (int j = 0; j < k; j++) {
          kernel(i, j) = kernel(i, j); // /norm;
        }
      }
      
      break;
      
  }
  
  kernel = kernel*alpha;
  
  if (k > 1) {
    *(result.Rs) = conv2(*(this->Rs), kernel, "full");
    *(result.Gs) = conv2(*(this->Gs), kernel, "full");
    *(result.Bs) = conv2(*(this->Bs), kernel, "full");
    *(result.As) = conv2(*(this->As), kernel, "full");
  } else {
    *(result.Rs) = *(this->Rs);
    *(result.Gs) = *(this->Gs);
    *(result.Bs) = *(this->Bs);
    *(result.As) = *(this->As);
  }
  //printf("%llu %llu %d %llu %llu\n", this->Rs->n_rows, this->Rs->n_cols, k, kernel.n_rows, kernel.n_cols);
  return result;
}

Matrix::~Matrix() {
  delete Rs;
  delete Gs;
  delete Bs;
  delete As;
  
  if (rs != NULL) {
    free(rs);
  }
  
  if (gs != NULL) {
    free(gs);
  }
  
  if (bs != NULL) {
    free(bs);
  }
  
  if (as != NULL) {
    free(as);
  }
}

Element *Element::get(string name) {
  if (s.count(name)) {
    return s[name];
  }
  
  return NULL;
}

Element *Element::create(SDL_Surface *surface, string name, int blur, int TH) {
  //printf("Creating: %s\n", name.c_str());
  if (s.count(name)) {
    printf("Element already exists.\n");
    exit(-1);
  }
  
  Element *element = new Element(surface, NULL, NULL, name, blur);
  element->TH = TH;
  s[name] = element;
  return element;
}

Element *Element::create(SDL_Texture *texture1, SDL_Texture *texture2, string name, int blur, int TH) {
  //printf("Creating: %s\n", name.c_str());
  if (s.count(name)) {
    printf("Element already exists.\n");
    exit(-1);
  }
  
  Element *element = new Element(NULL, texture1, texture2, name, blur);
  element->TH = TH;
  s[name] = element;
  return element;
}

void Element::draw(string name, int x, int y) {
  Element *element = Element::s[name];
  SDL_Texture *texture = element->frames[0];
  int TH = element->TH;
  if (TH == 0) {
    TH = texture->h;
  }
  
  int hp = texture->h;
  
  int which = now * 100;
  which = which % 200;
  which = which/10;
  which = which % 20;
  
  
  int which2 = now * 5;
  which2 = which2 % 20;
  which2 = which2/10;
  which2 = which2 % 20;
  
  {
    int w = texture->w;
    int h = texture->h;
    SDL_FRect loc = fr(x - w/2, y - TH/2, w, h);
    
    SDL_SetTextureBlendMode(texture, SDL_BLENDMODE_BLEND);
    SDL_SetRenderTarget(renderer, display);
    double alpha = 1.0;
    switch(which2) {
      case  1:
        alpha = 0.27861;
        break;
      case  2:
        alpha = 0.34769;
        break;
      case  3:
        alpha = 0.23604;
        break;
      case  4:
        alpha = 0.90626;
        break;
      case  5:
        alpha = 0.18128;
        break;
      case  6:
        alpha = 0.83891;
        break;
      case  7:
        alpha = 0.65583;
        break;
      case  8:
        alpha = 0.67807;
        break;
      case  9:
        alpha = 0.26559;
        break;
      case 10:
        alpha = 0.84693;
        break;
      case 11:
        alpha = 0.96019;
        break;
      case 12:
        alpha = 0.08594;
        break;
      case 13:
        alpha = 0.20313;
        break;
      case 14:
        alpha = 0.71988;
        break;
      case 15:
        alpha = 0.53455;
        break;
      case 16:
        alpha = 0.37288;
        break;
      case 17:
        alpha = 0.71428;
        break;
      case 18:
        alpha = 0.70419;
        break;
      case 19:
        alpha = 0.7003;
        break;
      case 20:
        alpha = 0.36108;
        break;
    }
    
    SDL_SetTextureAlphaModFloat(texture, 1-alpha/25.5);
    SDL_RenderTexture(renderer, texture, NULL, &loc);
    SDL_SetTextureAlphaModFloat(texture, 1.0);
    SDL_SetRenderTarget(renderer, NULL);
  }
  
  texture = element->rs[0];
  if (texture != NULL) {
    int w = texture->w;
    int h = texture->h;
    int factor = h - hp;
    Point ofr = element->ors[which];
    SDL_FRect loc_r = fr(x - w/2 + ofr.x, y - TH/2 - factor/2 + ofr.y, w, h);
    SDL_SetRenderTarget(renderer, DR);
    SDL_RenderTexture(renderer, texture, NULL, &loc_r);
    SDL_SetRenderTarget(renderer, NULL);
  }
  
  texture = element->gs[0];
  if (texture != NULL) {
    int w = texture->w;
    int h = texture->h;
    int factor = h - hp;
    Point ofg = element->ogs[0];
    SDL_FRect loc_g = fr(x - w/2 + ofg.x, y - TH/2 - factor/2 + ofg.y, w, h);
    SDL_SetRenderTarget(renderer, DG);
    SDL_RenderTexture(renderer, texture, NULL, &loc_g);
    SDL_SetRenderTarget(renderer, NULL);
  }
  
  texture = element->bs[0];
  if (texture != NULL) {
    int w = texture->w;
    int h = texture->h;
    int factor = h - hp;
    Point ofb = element->obs[which];
    SDL_FRect loc_b = fr(x - w/2 + ofb.x, y - TH/2 - factor/2 + ofb.y, w, h);
    SDL_SetRenderTarget(renderer, DB);
    SDL_RenderTexture(renderer, texture, NULL, &loc_b);
    SDL_SetRenderTarget(renderer, NULL);
  }
}

map<string, Element *> Element::s;


void Element::process(SDL_Surface *surface, SDL_Texture *texture1, SDL_Texture *texture2, string name, int blur) {
  if (texture1 == NULL) {
    texture1 = SDL_CreateTextureFromSurface(renderer, surface);
    SDL_SetTextureBlendMode(texture1, SDL_BLENDMODE_BLEND);
  }
  width = texture1->w;
  
  switch (blur) {
    case 0:
      times = { 0.0f };
      frames = { texture1 };
      rs = { NULL };
      gs = { NULL };
      bs = { NULL };
      ors = { { 0.0f, 0.0f } };
      ogs = { { 0.0f, 0.0f } };
      obs = { { 0.0f, 0.0f } };
      
      break;
      
    default:
      SDL_Texture *tr = NULL, *tb = NULL;
      if (surface != NULL) {
        Matrix m(surface);
        Matrix r = m.blur(blur, 0.7);
        tr = r.dump2();
        Matrix b = m.blur(blur, 0.9);
        tb = b.dump2();
      } else {
        Matrix m(texture2);
        //printf("Surface is null\n");
        Matrix r = m.blur(blur, 0.8);
        tr = r.dump2();
        Matrix b = m.blur(blur, 1.1);
        tb = b.dump2();
        
        //printf("%d %d Done\n", tr->w, tr->h);
      }
      
      times = { 0.0f };
      frames = { texture1 };
      rs = { tr };
      gs = { tb };
      bs = { tb };
      ors = { { 0.0f, 0.0f } };
      ogs = { { 0.0f, 0.0f } };
      obs.resize(20);
      obs[ 0] = { 0.4389924193300864f, 0.0f };
      obs[ 1] = { 2.7928974010788217f, 0.0f };
      obs[ 2] = { 0.02956275843481219f, 0.0f };
      obs[ 3] = { 0.40218538552878136f, 0.0f };
      obs[ 4] = { 3.4794037899852017f, 0.0f };
      obs[ 5] = { 1.6125630401149584f, 0.0f };
      obs[ 6] = { 0.7015590085143956f, 0.0f };
      obs[ 7] = { 3.896914047650351f, 0.0f };
      obs[ 8] = { 3.870905614848819f, 0.0f };
      obs[ 9] = { 2.231056963361899f, 0.0f };
      obs[10] = { 0.08084290417898504f, 0.0f };
      obs[11] = { 2.3758461067427543f, 0.0f };
      obs[12] = { 2.202193051050636f, 0.0f };
      obs[13] = { 2.8638780614874975f, 0.0f };
      obs[14] = { 0.48874025155497314f, 0.0f };
      obs[15] = { 1.8948491305757957f, 0.0f };
      obs[16] = { 0.0833037308038857f, 0.0f };
      obs[17] = { 0.09769827255241735f, 0.0f };
      obs[18] = { 3.443339761481782f, 0.0f };
      obs[19] = { 2.1841838852799786f, 0.0f };
      
      ors.resize(20);
      ors[ 0] = { -0.4389924193300864f, 0.0f };
      ors[ 1] = { -2.7928974010788217f, 0.0f };
      ors[ 2] = { -0.02956275843481219f, 0.0f };
      ors[ 3] = { -0.40218538552878136f, 0.0f };
      ors[ 4] = { -3.4794037899852017f, 0.0f };
      ors[ 5] = { -1.6125630401149584f, 0.0f };
      ors[ 6] = { -0.7015590085143956f, 0.0f };
      ors[ 7] = { -3.896914047650351f, 0.0f };
      ors[ 8] = { -3.870905614848819f, 0.0f };
      ors[ 9] = { -2.231056963361899f, 0.0f };
      ors[10] = { -0.08084290417898504f, 0.0f };
      ors[11] = { -2.3758461067427543f, 0.0f };
      ors[12] = { -2.202193051050636f, 0.0f };
      ors[13] = { -2.8638780614874975f, 0.0f };
      ors[14] = { -0.48874025155497314f, 0.0f };
      ors[15] = { -1.8948491305757957f, 0.0f };
      ors[16] = { -0.0833037308038857f, 0.0f };
      ors[17] = { -0.09769827255241735f, 0.0f };
      ors[18] = { -3.443339761481782f, 0.0f };
      ors[19] = { -2.1841838852799786f, 0.0f };
      break;
  }
}

Element::Element(SDL_Surface *surface, SDL_Texture *texture1, SDL_Texture *texture2, string name, int blur) : TH(0), name(name) {
  process(surface, texture1, texture2, name, blur);
}

//Element(SDL_CreateTextureFromSurface(renderer, surface), name, blur) { }
/*
  SDL_Texture *texture = SDL_CreateTextureFromSurface(renderer, surface);
  
  SDL_SetTextureBlendMode(texture, SDL_BLENDMODE_BLEND);
  width = texture->w;
  
  switch (blur) {
    case 0:
      times = { 0.0f };
      frames = { texture };
      rs = { NULL };
      gs = { NULL };
      bs = { NULL };
      ors = { { 0.0f, 0.0f } };
      ogs = { { 0.0f, 0.0f } };
      obs = { { 0.0f, 0.0f } };
      
      break;
      
    default:
      Matrix m(surface);
      Matrix r = m.blur(blur, 0.55);
      SDL_Texture *tr = r.dump2();
      Matrix b = m.blur(blur, 0.8);
      SDL_Texture *tb = b.dump2();
      times = { 0.0f };
      frames = { texture };
      rs = { tr };
      gs = { tb };
      bs = { tb };
      ors = { { 0.0f, 0.0f } };
      ogs = { { 0.0f, 0.0f } };
      //obs = { { 0.0f, 0.0f } };
      obs.resize(20);
      obs[ 0] = { 0.4389924193300864f, 0.0f };
      obs[ 1] = { 2.7928974010788217f, 0.0f };
      obs[ 2] = { 0.02956275843481219f, 0.0f };
      obs[ 3] = { 0.40218538552878136f, 0.0f };
      obs[ 4] = { 3.4794037899852017f, 0.0f };
      obs[ 5] = { 1.6125630401149584f, 0.0f };
      obs[ 6] = { 0.7015590085143956f, 0.0f };
      obs[ 7] = { 3.896914047650351f, 0.0f };
      obs[ 8] = { 3.870905614848819f, 0.0f };
      obs[ 9] = { 2.231056963361899f, 0.0f };
      obs[10] = { 0.08084290417898504f, 0.0f };
      obs[11] = { 2.3758461067427543f, 0.0f };
      obs[12] = { 2.202193051050636f, 0.0f };
      obs[13] = { 2.8638780614874975f, 0.0f };
      obs[14] = { 0.48874025155497314f, 0.0f };
      obs[15] = { 1.8948491305757957f, 0.0f };
      obs[16] = { 0.0833037308038857f, 0.0f };
      obs[17] = { 0.09769827255241735f, 0.0f };
      obs[18] = { 3.443339761481782f, 0.0f };
      obs[19] = { 2.1841838852799786f, 0.0f };
      
      ors.resize(20);
      ors[ 0] = { -0.4389924193300864f, 0.0f };
      ors[ 1] = { -2.7928974010788217f, 0.0f };
      ors[ 2] = { -0.02956275843481219f, 0.0f };
      ors[ 3] = { -0.40218538552878136f, 0.0f };
      ors[ 4] = { -3.4794037899852017f, 0.0f };
      ors[ 5] = { -1.6125630401149584f, 0.0f };
      ors[ 6] = { -0.7015590085143956f, 0.0f };
      ors[ 7] = { -3.896914047650351f, 0.0f };
      ors[ 8] = { -3.870905614848819f, 0.0f };
      ors[ 9] = { -2.231056963361899f, 0.0f };
      ors[10] = { -0.08084290417898504f, 0.0f };
      ors[11] = { -2.3758461067427543f, 0.0f };
      ors[12] = { -2.202193051050636f, 0.0f };
      ors[13] = { -2.8638780614874975f, 0.0f };
      ors[14] = { -0.48874025155497314f, 0.0f };
      ors[15] = { -1.8948491305757957f, 0.0f };
      ors[16] = { -0.0833037308038857f, 0.0f };
      ors[17] = { -0.09769827255241735f, 0.0f };
      ors[18] = { -3.443339761481782f, 0.0f };
      ors[19] = { -2.1841838852799786f, 0.0f };
      break;
  }
  
}*/



void draw_line(int x1, int y1, int x2, int y2, int r, int g, int b, int a) {
  if (x1 > x2) {
    int temp;
    
    temp = x2;
    x2 = x1;
    x1 = temp;
    
    temp = y2;
    y2 = y1;
    y1 = temp;
  }
  
  int u = x2 - x1;
  int v = y2 - y1;
  
  string id = (format("line[%d,%d,%d,%d,%d,%d]") % u % v % r % g % b % a).str();
  Element *element = Element::get(id);
  if (element == NULL) {
    
    SDL_Texture *texture1 = SDL_CreateTexture(renderer, PF, SDL_TEXTUREACCESS_TARGET, u + 5, v + 5);
    SDL_SetTextureBlendMode(texture1, SDL_BLENDMODE_BLEND);
    SDL_SetRenderTarget(renderer, texture1);
    SDL_SetRenderDrawColor(renderer, r, g, b, a);
    if (v > 0) {
      SDL_RenderLine(renderer, 2.5, 2.5, u + 2.5, v + 2.5);
    } else {
      v = 2.5 - v;
      SDL_RenderLine(renderer, 2.5, v + 2.5, u + 2.5, 2.5);
    }
    SDL_SetRenderDrawColor(renderer, 0, 0, 0, 0);
    SDL_SetRenderTarget(renderer, NULL);
    
    
    SDL_Texture *texture2 = SDL_CreateTexture(renderer, PF, SDL_TEXTUREACCESS_STREAMING, u + 5, v + 5);
    SDL_SetTextureBlendMode(texture2, SDL_BLENDMODE_BLEND);
    SDL_SetRenderTarget(renderer, texture2);
    SDL_SetRenderDrawColor(renderer, r, g, b, a);
    if (v > 0) {
      SDL_RenderLine(renderer, 2.5, 2.5, u + 2.5, v + 2.5);
    } else {
      v = 2.5 - v;
      SDL_RenderLine(renderer, 2.5, v + 2.5, u + 2.5, 2.5);
    }
    SDL_SetRenderDrawColor(renderer, 0, 0, 0, 0);
    SDL_SetRenderTarget(renderer, NULL);
    element = Element::create(texture1, texture2, id, 7, 0);
    SDL_DestroyTexture(texture2);
  }
  
  Element::draw(id, x1 + u/2.0, y1 + v/2.0);
}


void draw_line2(double x1, double y1, double x2, double y2, int r, int g, int b, int a) {
  int margin = 10;
  if (x1 > x2) {
    double temp;
    
    temp = x2;
    x2 = x1;
    x1 = temp;
    
    temp = y2;
    y2 = y1;
    y1 = temp;
  }
  
  double u = x2 - x1;
  double v = y2 - y1;
  
  int ui = u;
  int vi = v;
  
  int h = fabs(v) + margin;
  string id = (format("line[%d,%d,%d,%d,%d,%d]") % ui % vi % r % g % b % a).str();
  Element *element = Element::get(id);
  if (element == NULL) {
    
    SDL_Texture *texture1 = SDL_CreateTexture(renderer, PF, SDL_TEXTUREACCESS_TARGET, u + margin, h);
    
    SDL_SetRenderTarget(renderer, texture1);
    SDL_SetRenderDrawColor(renderer, 0, 0, 0, 0);
    SDL_RenderClear(renderer);
    SDL_SetTextureBlendMode(texture1, SDL_BLENDMODE_BLEND);
    SDL_SetRenderDrawColor(renderer, r, g, b, a);
    if (v > 0) {
      thickLineRGBA(renderer, margin/2, margin/2, u + margin/2, v + margin/2, 5, r, g, b, a);
    } else {
      int v2 = round(-v + margin/2);
      v2 = fabs(v2);
      thickLineRGBA(renderer, margin/2, v2, u + margin/2, margin/2, 5, r, g, b, a);
    }
    SDL_SetRenderDrawColor(renderer, 0, 0, 0, 0);
    SDL_SetRenderTarget(renderer, NULL);
    
    SDL_Texture *texture2 = SDL_CreateTexture(software, PF, SDL_TEXTUREACCESS_STREAMING, u + margin, h);
    
    SDL_SetRenderTarget(software, texture2);
    SDL_SetRenderDrawColor(software, 0, 0, 0, 0);
    SDL_RenderClear(software);
    SDL_SetTextureBlendMode(texture2, SDL_BLENDMODE_BLEND);
    SDL_SetRenderDrawColor(software, r, g, b, a);
    if (v > 0) {
      thickLineRGBA(software, margin/2, margin/2, u + margin/2, v + margin/2, 5, r, g, b, a);
    } else {
      int v2 = round(-v + margin/2);
      v2 = fabs(v2);
      thickLineRGBA(software, margin/2, v2, u + margin/2, margin/2, 5, r, g, b, a);
    }
    SDL_SetRenderDrawColor(software, 0, 0, 0, 0);
    SDL_SetRenderTarget(software, NULL);
    element = Element::create(texture1, texture2, id, 27, 0);
    SDL_DestroyTexture(texture2);
  }
  
  Element::draw(id, x1 + u/2.0, y1 + v/2.0);
}
