#ifndef __INPUT_H_
#define __INPUT_H_

typedef struct {
  bool E;
} KeyState;

#endif
