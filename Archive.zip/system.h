#ifndef __SYSTEM_H_
#define __SYSTEM_H_

extern double now;
extern double start;
double upnow();
void init_system();
double usage();

#endif
