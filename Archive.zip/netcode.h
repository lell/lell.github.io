#ifndef __NETCODE_H_
#define __NETCODE_H_

#include "snappy/snappy.h"

#include <pthread.h>

void *sthread(void *ptr);
void init_server();

#endif
