#ifndef __TEXT_H_
#define __TEXT_H_

#include <SDL3/SDL.h>
#include <SDL3_ttf/SDL_ttf.h>
#include <string>
#include <map>

using std::map;
using std::string;

class Font {
  
private:
  TTF_Font *font;
  int TH;
  int blur;
  /*map<string, SDL_Texture *> texts;
  map<string, int> ws;
  map<string, int> hs;*/
  string name;
  
public:
  Font(string name, int size, int blur = 0);
  void draw_text(string text, int x, int y, int r, int g, int b, int a = 0xFF);
  void draw_textl(string text, int x, int y, int r, int g, int b, int a = 0xFF);
};

#endif
