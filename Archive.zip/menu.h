#ifndef __MENU_H_
#define __MENU_H_

#include <vector>
#include <string>

#include "text.h"
#include "graphics.h"

using namespace vector;
using namespace string;

class Menu {
public:
  vector<string> items;
  void render() {
    for (String item : items) {
      
    }
  }
};

#endif
