#include <iostream>
#include <ctime>
#include <cstdio>
#include <cstdlib>
#include <string>
#include <boost/format.hpp>
#include <map>
#include <vector>
#include <SDL3/SDL.h>
#include <SDL3/SDL_pixels.h>
#include <SDL3_ttf/SDL_ttf.h>
#include "SDL_image.h"
#include <Eigen/Dense>
#include <armadillo>
#include <ctime>
#include <fstream>
#include <sstream>
#include <chrono>

#include "SDL3_gfx/SDL3_gfxPrimitives.h"

#include "netcode.h"
#include "graphics.h"
#include "geometry.h"
#include "random.h"
#include "text.h"
#include "system.h"

#include "Machine.h"

using std::string;
using std::map;
using std::stringstream;
using std::cout;
using std::cin;
using std::endl;
using std::vector;
using boost::format;

using Eigen::MatrixXd;

using namespace snappy;
using namespace cereal;
using namespace arma;

void tests() {
  mat A(4, 5, fill::randu);
  mat B(4, 5, fill::randu);
  
  cout << A*B.t() << endl;
  
  MatrixXd m(2,2);
  m(0,0) = 3;
  m(1,0) = 2.5;
  m(0,1) = -1;
  m(1,1) = m(1,0) + m(0,1);
  std::cout << m << std::endl;
  
  char *input = "This is a test";
  string output;
  Compress(input, strlen(input), &output);
  string result;
  Uncompress(output.c_str(), output.length(), &result);
  std::cout << result << std::endl;
  
  string s;
  {
    std::stringstream so;
    BinaryOutputArchive oarchive(so);
    Machine m1;
    m1.dx = 7;
    oarchive(m1);
    s = so.str();
  }
  
  {
    stringstream si;
    si << s;
    BinaryInputArchive iarchive(si);
    
    Machine m1;
    iarchive(m1);
    printf(">> %lld\n", m1.dx);
  }
  
  vector<double> zz = linspan(0, 4, 4);
  for (double z : zz) {
    cout << z << endl;
  }
  
  
  /*SDL_Surface *surface = IMG_Load("preview.png");
   
   if (surface == NULL) {
   printf("Error: Could not open preview.png");
   exit(-1);
   }
   Matrix mm(surface);
   mm.dump(surface);*/
  
  /*SDL_Texture *image = SDL_CreateTextureFromSurface(renderer, surface);
   Matrix m2 = mm.blur(20);
   SDL_Surface *surface7 = m2.dump(surface->format);
   SDL_DestroySurface(surface);
   SDL_Texture *image7 = SDL_CreateTextureFromSurface(renderer, surface7);
   SDL_DestroySurface(surface7);*/
  
  
  
  /*SDL_FRect loc3 = { 25.0f, 25.0f, 100.f, 100.f };
   SDL_RenderTexture(renderer, image, NULL, &loc3);
   
   SDL_FRect loc7 = { 125.0f, 125.0f, 100.f, 100.f };
   SDL_RenderTexture(renderer, image7, NULL, &loc7);*/
  
}

int main(int argc, const char * argv[]) {
  tests();
  init_server();
  init_random();
  init_system();
  init_graphics();

  bool quit = false;
  
  //The event data
  SDL_Event e;
  SDL_zero( e );
  
  SDL_Gamepad *controller = NULL;
  
  int found = SDL_HasGamepad();
  
  if (found) {
    printf("Found joystick.\n");
  } else {
    printf("Didn't find joystick.\n");
  }
  
//  typedef struct SDL_KeyboardEvent
//  {
//    SDL_EventType type;     /**< SDL_EVENT_KEY_DOWN or SDL_EVENT_KEY_UP */
//    Uint32 reserved;
//    Uint64 timestamp;       /**< In nanoseconds, populated using SDL_GetTicksNS() */
//    SDL_WindowID windowID;  /**< The window with keyboard focus, if any */
//    SDL_KeyboardID which;   /**< The keyboard instance id, or 0 if unknown or virtual */
//    SDL_Scancode scancode;  /**< SDL physical key code */
//    SDL_Keycode key;        /**< SDL virtual key code */
//    SDL_Keymod mod;         /**< current key modifiers */
//    Uint16 raw;             /**< The platform dependent scancode for this event */
//    bool down;              /**< true if the key is pressed */
//    bool repeat;            /**< true if this is a key repeat */
//  } SDL_KeyboardEvent;
  
  Uint64 ts0 = SDL_GetTicksNS();
  Uint64 nsfr = 1000 * 1000 * 1000 / 30;
  while( quit == false ) {
    while( SDL_PollEvent( &e ) ) {
      if( e.type == SDL_EVENT_QUIT ) {
        quit = true;
      } else if (e.type == SDL_EVENT_KEY_DOWN) {
        SDL_KeyboardEvent k = e.key;
        SDL_Keycode c = k.key;
        Uint64 t2 = SDL_GetTicksNS();
        if (c == SDLK_E) {
          printf("keydown: e %llu %llu %llu\n", (k.timestamp - ts0)/nsfr, (t2 - ts0)/nsfr, k.timestamp - ts0);
        }
      }
    }
    // input();
    // advance();
    refresh();
  }
  return 0;
}
