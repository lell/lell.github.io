#ifndef __RANDOM_H_
#define __RANDOM_H_

#include <boost/range/iterator_range.hpp>
#include <boost/random/uniform_int_distribution.hpp>
#include <boost/random.hpp>
#include <ctime>

using namespace boost;
using namespace boost::random;

extern mt19937 rng;

static inline void init_random() {
  rng.seed((unsigned)time(NULL));
}

static inline uint64_t uniform(int min, int max) {
  uniform_int_distribution<> result(min, max);
  return result(rng);
}


#endif
