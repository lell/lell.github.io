#ifndef __ASSETS_H_
#define __ASSETS_H_

#endif
